#ifndef _lcd9696_H
#define _lcd9696_H

#include "public.h"

//管脚定义
sbit SCK = P2^0;
sbit SDA = P2^1;
sbit RES = P2^2;
sbit DC  = P2^3;
sbit CS  = P2^4;

#define OLED_W_D0(x)		SCK=(x)
#define OLED_W_D1(x)		SDA=(x)
#define OLED_W_RES(x)		RES=(x)
#define OLED_W_DC(x)		DC=(x)
#define OLED_W_CS(x)		CS=(x)

typedef unsigned char uint8_t;
typedef unsigned long uint32_t;
typedef long int32_t;

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_Show_16HZ(uint8_t x, uint8_t y, uint8_t *cn);

#endif
